export function drawTab2Content(heading, optionContentElement) {

}
